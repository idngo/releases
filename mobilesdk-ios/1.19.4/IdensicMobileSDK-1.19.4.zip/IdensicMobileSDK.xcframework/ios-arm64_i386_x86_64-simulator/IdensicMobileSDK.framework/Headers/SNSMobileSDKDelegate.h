//
//  SNSMobileSDKDelegate.h
//  ssmSDK
//
//  Created by Roman Silin on 22.02.2022.
//  Copyright © 2022 Sum & Substance. All rights reserved.
//

#ifndef SNSMobileSDKDelegate_h
#define SNSMobileSDKDelegate_h

@class SNSMobileSDK;

@protocol SNSMobileSDKDelegate

@optional

/**
 * Implement if you want to present a custom country picker
 *
 * @discussion It's up to you to present and dismiss the picker. In case the user do pick a country, call `onSelect` passing the selected country code.
 */
- (void)      snsMobileSDK:(nonnull SNSMobileSDK *)sdk
   presentCountryPickerFor:(nonnull NSDictionary<NSString *, NSString *> *)countries
                      from:(nonnull UIViewController *)presentingViewController
                     title:(nullable NSString *)title
               preselected:(nullable NSString *)countryCode
                  onSelect:(void (^ _Nonnull)(NSString * _Nonnull))onSelect;

/**
 * Implement if you want to show a custom instruction view.
 *
 * @discussion Returning `nil` means the corresponding Instructions view will be constructed and shown by the sdk itself
 */
- (nullable UIView *)    snsMobileSDK:(nonnull SNSMobileSDK *)sdk
  instructionsViewForVerificationStep:(nonnull SNSVerificationStepKey)verificationStep
                         documentType:(nonnull SNSDocumentTypeKey)documentType
                            sceneType:(nonnull SNSSceneType)sceneType;

@end

#endif /* SNSMobileSDKDelegate_h */
