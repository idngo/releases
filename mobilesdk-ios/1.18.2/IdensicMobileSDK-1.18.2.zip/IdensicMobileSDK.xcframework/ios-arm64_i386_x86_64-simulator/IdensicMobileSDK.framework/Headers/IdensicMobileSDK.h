//
//  IdensicMobileSDK.h
//  IdensicMobileSDK
//

#import <Foundation/Foundation.h>

//! Project version number for IdensicMobileSDK.
FOUNDATION_EXPORT double IdensicMobileSDKVersionNumber;

//! Project version string for IdensicMobileSDK.
FOUNDATION_EXPORT const unsigned char IdensicMobileSDKVersionString[];

#import <IdensicMobileSDK/SNSMobileSDK.h>
#import <IdensicMobileSDK/SNSSupportItem.h>
#import <IdensicMobileSDK/SNSActionResult.h>
#import <IdensicMobileSDK/SNSEvent.h>
#import <IdensicMobileSDK/SNSTheme.h>
