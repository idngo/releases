//
//  IdensicMobileSDK_MRTDReader.h
//  IdensicMobileSDK_MRTDReader
//

#import <Foundation/Foundation.h>

//! Project version number for IdensicMobileSDK_MRTDReader.
FOUNDATION_EXPORT double IdensicMobileSDK_MRTDReaderVersionNumber;

//! Project version string for IdensicMobileSDK_MRTDReader.
FOUNDATION_EXPORT const unsigned char IdensicMobileSDK_MRTDReaderVersionString[];

