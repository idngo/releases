//
//  CBRMobileSDKInfo.h
//  CyberityMobileSDK
//

#ifndef CBRMobileSDKInfoProtocol_h
#define CBRMobileSDKInfoProtocol_h

/**
 * SDK's Info Protocol
 */
@protocol CBRMobileSDKInfoProtocol <NSObject>

/// The SDK's version number
@property (nonnull, readonly) NSString *version;
/// The SDK's build number
@property (nonnull, readonly) NSString *build;
/// The list of the steps supported
@property (nonnull, readonly) NSArray<CBRVerificationStepKey> *supportedSteps;
/// The list of the pluggable modules and their status
@property (nonnull, readonly) NSDictionary<NSString *, NSString *> *modules;

@end

#endif /* CBRMobileSDKInfoProtocol_h */
