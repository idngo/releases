//
//  CBRThemeSection.h
//  CyberityMobileSDK
//

#import <Foundation/Foundation.h>
#import "CBRMobileSDK+Enums.h"

#ifndef CBR_THEME_DEPRECATED
    #ifndef CBR_THEME_SUPPRESS_DEPRECATED_WARNINGS
        #define CBR_THEME_DEPRECATED(params...) __attribute((deprecated(params)))
    #else
        #define CBR_THEME_DEPRECATED(params...)
    #endif
#endif

@interface CBRThemeSection : NSObject

@end
