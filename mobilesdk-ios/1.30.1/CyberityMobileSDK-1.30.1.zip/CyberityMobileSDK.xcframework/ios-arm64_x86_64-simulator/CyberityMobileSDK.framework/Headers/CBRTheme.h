//
//  CBRTheme.h
//  CyberityMobileSDK
//

#import <UIKit/UIKit.h>

#import "CBRThemeFonts.h"
#import "CBRThemeColors.h"
#import "CBRThemeImages.h"
#import "CBRThemeMetrics.h"

typedef NSString * _Nullable(^CBRAssetNameHandler)(NSString * _Nonnull assetName);

@interface CBRTheme : NSObject

+ (nonnull instancetype)fromJSON:(nullable NSDictionary<NSString *, id> *)json NS_SWIFT_NAME(init(fromJSON:));
+ (nonnull instancetype)fromJSON:(nullable NSDictionary<NSString *, id> *)json
                      assetsPath:(nullable NSString *)assetsPath NS_SWIFT_NAME(init(fromJSON:assetsPath:));
+ (nonnull instancetype)fromJSON:(nullable NSDictionary<NSString *, id> *)json
                assetNameHandler:(nullable CBRAssetNameHandler)assetNameHandler NS_SWIFT_NAME(init(fromJSON:assetNameHandler:));
+ (nonnull instancetype)fromJSON:(nullable NSDictionary<NSString *, id> *)json
                      assetsPath:(nullable NSString *)assetsPath
                assetNameHandler:(nullable CBRAssetNameHandler)assetNameHandler NS_SWIFT_NAME(init(fromJSON:assetsPath:assetNameHandler:));

+ (nonnull instancetype)darkTheme;

#pragma mark -

@property (nonatomic, nonnull) CBRThemeFonts *fonts;
@property (nonatomic, nonnull) CBRThemeColors *colors;
@property (nonatomic, nonnull) CBRThemeImages *images;
@property (nonatomic, nonnull) CBRThemeMetrics *metrics;

#pragma mark -

typedef NSString* CBRIdDocType;

typedef NS_ENUM(NSInteger, CBRThemeDimmingEffect) {
    CBRThemeDimmingEffect_None,
    CBRThemeDimmingEffect_Blur CBR_THEME_DEPRECATED("Use .fadeIn instead."),
    CBRThemeDimmingEffect_FadeIn,
};

#pragma mark - General

@property (nonatomic) UIStatusBarStyle cbr_preferredStatusBarStyle CBR_THEME_DEPRECATED("Replaced with `metrics.commonStatusBarStyle`");

@property (nonatomic, nullable) UIColor *cbr_navbarBarTintColor CBR_THEME_DEPRECATED("Not used. The background color of the navigation bar matches the screen background.");
@property (nonatomic, nullable) UIColor *cbr_navbarTintColor CBR_THEME_DEPRECATED("Replaced with `colors.navigationBarItem`");

@property (nonatomic, nullable) UIImage *cbr_closeButtonImage CBR_THEME_DEPRECATED("Use `images.iconClose` instead.");
@property (nonatomic, nullable) UIImage *cbr_searchIconImage CBR_THEME_DEPRECATED("Use `images.iconSearch` instead.");

@property (nonatomic, nullable) UIColor *cbr_alertTintColor CBR_THEME_DEPRECATED("Replaced with `colors.alertTint`");

@property (nonatomic, nullable) UIFont *cbr_poweredByFont CBR_THEME_DEPRECATED("Replaced with `fonts.caption`");
@property (nonatomic, nullable) UIColor *cbr_poweredByColor CBR_THEME_DEPRECATED("Replaced with `colors.contentWeak`");

/**
 * Matches to `fonts.caption` by default
 */
@property (nonatomic, nullable) UIFont *cbr_loadingMessageFont;
/**
 * Matches to `colors.contentWeak` by default
 */
@property (nonatomic, nullable) UIColor *cbr_loadingMessageColor;
@property (nonatomic) UIActivityIndicatorViewStyle cbr_loadingSpinnerStyle CBR_THEME_DEPRECATED("Replaced with `metrics.activityIndicatorStyle`");

#pragma mark - Buttons

/**
 * Matches to `fonts.subtitle1` by default
 */
@property (nonatomic, nullable) UIFont *cbr_actionButtonFont;
@property (nonatomic) CGFloat cbr_actionButtonCornerRadius CBR_THEME_DEPRECATED("Use `metrics.buttonCornerRadius` instead.");
@property (nonatomic) CGFloat cbr_actionButtonHeight CBR_THEME_DEPRECATED("Use `metrics.buttonHeight` instead.");

@property (nonatomic, nullable) UIColor *cbr_actionButtonTitleColor CBR_THEME_DEPRECATED("Replaced with `colors.primaryButtonContent`");
@property (nonatomic, nullable) UIColor *cbr_actionButtonBackgroundColor CBR_THEME_DEPRECATED("Replaced with `colors.primaryButtonBackground`");
@property (nonatomic, nullable) UIColor *cbr_actionButtonHighlightedTitleColor CBR_THEME_DEPRECATED("Replaced with `colors.primaryButtonContentHighlighted`");
@property (nonatomic, nullable) UIColor *cbr_actionButtonHighlightedBackgroundColor CBR_THEME_DEPRECATED("Replaced with `colors.primaryButtonBackgroundHighlighted`");

@property (nonatomic, nullable) UIColor *cbr_alternativeButtonTitleColor CBR_THEME_DEPRECATED("Replaced with `colors.secondaryButtonContent`");
@property (nonatomic, nullable) UIColor *cbr_alternativeButtonBackgroundColor CBR_THEME_DEPRECATED("Replaced with `colors.secondaryButtonBackground`");
@property (nonatomic, nullable) UIColor *cbr_alternativeButtonHighlightedTitleColor CBR_THEME_DEPRECATED("Replaced with `colors.secondaryButtonContentHighlighted`");
@property (nonatomic, nullable) UIColor *cbr_alternativeButtonHighlightedBackgroundColor CBR_THEME_DEPRECATED("Replaced with `colors.secondaryButtonBackgroundHighlighted`");
/**
 * Matches to `colors.secondaryButtonContent` by default
 */
@property (nonatomic, nullable) UIColor *cbr_alternativeButtonBorderColor;

#pragma mark - Oops Screen

/**
 * Matches to `fonts.headline2` by default
 */
@property (nonatomic, nullable) UIFont *cbr_OopsScreenTitleFont;
/**
 * Matches to `fonts.subtitle2` by default
 */
@property (nonatomic, nullable) UIFont *cbr_OopsScreenTextFont;
/**
 * Matches to `colors.contentStrong` by default
 */
@property (nonatomic, nullable) UIColor *cbr_OopsScreenTitleColor;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_OopsScreenTextColor;
/**
 * Matches to `colors.contentLink` by default
 */
@property (nonatomic, nullable) UIColor *cbr_OopsScreenLinkColor;

/**
 * Matches to `images.pictureWarning` by default
 */
@property (nonatomic, nullable) UIImage *cbr_OopsScreenNetworkFailImage;
/**
 * Matches to `images.pictureFailure` by default
 */
@property (nonatomic, nullable) UIImage *cbr_OopsScreenFatalFailImage;

@property (nonatomic, nullable) UIImage *cbr_OopsScreenWordlessNetworkFailImage;
@property (nonatomic, nullable) UIImage *cbr_OopsScreenWordlessFatalFailImage;
@property (nonatomic, nullable) UIImage *cbr_OopsScreenWordlessRetryButtonImage;
@property (nonatomic, nullable) UIImage *cbr_OopsScreenWordlessGoBackButtonImage;

#pragma mark - Status Screen

/**
 * Matches to `colors.backgroundCommon` by default
 */
@property (nonatomic, nullable) UIColor *cbr_StatusScreenBackgroundColor;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_StatusScreenSpinnerColor;

/**
 * Matches to `fonts.headline1` by default
 */
@property (nonatomic, nullable) UIFont *cbr_StatusHeaderTitleFont;
/**
 * Matches to `fonts.subtitle2` by default
 */
@property (nonatomic, nullable) UIFont *cbr_StatusHeaderSubtitleFont;
/**
 * Matches to `fonts.subtitle2` by default
 */
@property (nonatomic, nullable) UIFont *cbr_StatusHeaderTextFont;
/**
 * Matches to `colors.contentStrong` by default
 */
@property (nonatomic, nullable) UIColor *cbr_StatusHeaderTitleColor;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_StatusHeaderSubtitleColor;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_StatusHeaderTextColor;

/**
 * Default is .fadeIn
 */
@property (nonatomic) CBRThemeDimmingEffect cbr_StatusFooterDimmingEffect;
/**
 * Default is .fadeIn
 */
@property (nonatomic) CBRThemeDimmingEffect cbr_StatusFooterDimmingEffectDark;
@property (nonatomic) UIBlurEffectStyle cbr_StatusFooterBlurEffectStyle CBR_THEME_DEPRECATED("Unused");

/**
 * Matches to `fonts.caption` by default
 */
@property (nonatomic, nullable) UIFont *cbr_StatusFooterTextFont;
/**
 * Matches to `colors.backgroundCommon` by default
 */
@property (nonatomic, nullable) UIColor *cbr_StatusFooterBackgroundColor;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_StatusFooterTextColor;
/**
 * Matches to `colors.contentLink` by default
 */
@property (nonatomic, nullable) UIColor *cbr_StatusFooterLinkColor;

/**
 * Size of the image displayed at the header of the Status Screen
 *
 * Default is 112pt x 112pt
 */
@property (nonatomic) CGSize cbr_StatusHeaderImageSize;

/**
 * An optional image displayed on Status Screen when the applicant has been approved. If it's defined, it will be used instead of the steps list.
 *
 * Matches to `images.pictureSuccess` by default
 */
@property (nonatomic, nullable) UIImage *cbr_StatusScreenApprovedImage;
/**
 * An optional image displayed on Status Screen when the applicant has been finally rejected.
 *
 * Matches to `images.pictureFailure` by default
 */
@property (nonatomic, nullable) UIImage *cbr_StatusScreenFinalRejectImage;

#pragma mark - idDocs

/**
 * The paddings applied to idDoc status cells at the Status Screen
 *
 * Default are: 10pt vertically and 12pt horizontally
 */
@property (nonatomic) UIEdgeInsets cbr_idDocStatusPaddings;

/**
 * The horizontal spacing between icons and the texts on idDoc status cells at the Status Screen
 *
 * Default is 8pt
 */
@property (nonatomic) CGFloat cbr_idDocStatusIconSpacing;

/**
 * The vertical spacing between the texts on idDoc status cells at the Status Screen
 *
 * Default is 2pt
 */
@property (nonatomic) CGFloat cbr_idDocStatusTextsSpacing;

@property (nonatomic, nullable) UIFont *cbr_idDocStatusPromptTextFont CBR_THEME_DEPRECATED("Unused");
@property (nonatomic, nullable) UIColor *cbr_idDocStatusPromptTextColor CBR_THEME_DEPRECATED("Unused");
@property (nonatomic, nullable) UIColor *cbr_idDocStatusPromptBackgroundColor CBR_THEME_DEPRECATED("Unused");

/**
 * Matches to `fonts.subtitle1` by default
 */
@property (nonatomic, nullable) UIFont *cbr_idDocStatusSubmittedTitleFont;
/**
 * Matches to `fonts.body` by default
 */
@property (nonatomic, nullable) UIFont *cbr_idDocStatusSubmittedSubtitleFont;
/**
 * Matches to `colors.contentWarning` by default
 */
@property (nonatomic, nullable) UIColor *cbr_idDocStatusSubmittedTextColor;
/**
 * Matches to `colors.backgroundWarning` by default
 */
@property (nonatomic, nullable) UIColor *cbr_idDocStatusSubmittedBackgroundColor;
@property (nonatomic, nullable) UIImage *cbr_idDocStatusSubmittedImage CBR_THEME_DEPRECATED("Use images.setIcon(:forVerificationStep:andState:)");

/**
 * Matches to `fonts.subtitle1` by default
 */
@property (nonatomic, nullable) UIFont *cbr_idDocStatusNotSubmittedTitleFont;
/**
 * Matches to `fonts.body` by default
 */
@property (nonatomic, nullable) UIFont *cbr_idDocStatusNotSubmittedSubtitleFont;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_idDocStatusNotSubmittedTextColor;
/**
 * Matches to `colors.backgroundNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_idDocStatusNotSubmittedBackgroundColor;
@property (nonatomic, nullable) UIImage *cbr_idDocStatusNotSubmittedImage CBR_THEME_DEPRECATED("Use images.setIcon(:forVerificationStep:andState:)");

/**
 * Matches to `fonts.subtitle1` by default
 */
@property (nonatomic, nullable) UIFont *cbr_idDocStatusReviewingTitleFont;
/**
 * Matches to `fonts.body` by default
 */
@property (nonatomic, nullable) UIFont *cbr_idDocStatusReviewingSubtitleFont;
/**
 * Matches to `colors.contentWarning` by default
 */
@property (nonatomic, nullable) UIColor *cbr_idDocStatusReviewingTextColor;
/**
 * Matches to `colors.backgroundWarning` by default
 */
@property (nonatomic, nullable) UIColor *cbr_idDocStatusReviewingBackgroundColor;
@property (nonatomic, nullable) UIImage *cbr_idDocStatusReviewingImage CBR_THEME_DEPRECATED("Use images.setIcon(:forVerificationStep:andState:)");

/**
 * Matches to `fonts.subtitle1` by default
 */
@property (nonatomic, nullable) UIFont *cbr_idDocStatusDeclinedTitleFont;
/**
 * Matches to `fonts.body` by default
 */
@property (nonatomic, nullable) UIFont *cbr_idDocStatusDeclinedSubtitleFont;
/**
 * Matches to `colors.contentCritical` by default
 */
@property (nonatomic, nullable) UIColor *cbr_idDocStatusDeclinedTextColor;
/**
 * Matches to `colors.backgroundCritical` by default
 */
@property (nonatomic, nullable) UIColor *cbr_idDocStatusDeclinedBackgroundColor;
@property (nonatomic, nullable) UIImage *cbr_idDocStatusDeclinedImage CBR_THEME_DEPRECATED("Use images.setIcon(:forVerificationStep:andState:)");

/**
 * Matches to `fonts.subtitle1` by default
 */
@property (nonatomic, nullable) UIFont *cbr_idDocStatusApprovedTitleFont;
/**
 * Matches to `fonts.body` by default
 */
@property (nonatomic, nullable) UIFont *cbr_idDocStatusApprovedSubtitleFont;
/**
 * Matches to `colors.contentSuccess` by default
 */
@property (nonatomic, nullable) UIColor *cbr_idDocStatusApprovedTextColor;
/**
 * Matches to `colors.backgroundSuccess` by default
 */
@property (nonatomic, nullable) UIColor *cbr_idDocStatusApprovedBackgroundColor;
@property (nonatomic, nullable) UIImage *cbr_idDocStatusApprovedImage CBR_THEME_DEPRECATED("Use images.setIcon(:forVerificationStep:andState:)");

/**
 * Matches to `metrics.cardCornerRadius` by default
 */
@property (nonatomic) CGFloat cbr_idDocBackgroundCornerRadius;
/**
 * Used to estimate the highlighted background color by applying the factor to the normal background color
 *
 * Default is 0.05f
 */
@property (nonatomic) CGFloat cbr_idDocHighlightDarkFactor;

/**
 * Used to estimate the color of the disclosure indicator by applying the factor to the normal background color
 *
 * The dark factor has no effect when `cbr_idDocDisclosureTintColor` is not nil.
 *
 * Default is 0.15f
 */
@property (nonatomic) CGFloat cbr_idDocDisclosureDarkFactor;
/**
 * The disclosure color, if defined, is applied instead of the `cbr_idDocDisclosureDarkFactor`
 *
 * Matches to `colors.contentWeak` by default
 */
@property (nonatomic, nullable) UIColor *cbr_idDocDisclosureTintColor;
/**
 * Matches to `images.iconDisclosure` by default
 */
@property (nonatomic, nullable) UIImage *cbr_idDocDisclosureImage;

@property (nonatomic, nullable) UIImage *cbr_idDocTypeDefaultImage CBR_THEME_DEPRECATED("Use `images.documentTypeIcons[.default]` instead");
@property (nonatomic, nullable) NSDictionary<CBRIdDocType, UIImage *> *cbr_idDocTypeImages CBR_THEME_DEPRECATED("Use `images.documentTypeIcons` instead");

#pragma mark - DocType Selector Screen

/**
 * Matches to `colors.backgroundCommon` by default
 */
@property (nonatomic, nullable) UIColor *cbr_DocTypeScreenBackgroundColor;

/**
 * Matches to `fonts.caption` by default
 */
@property (nonatomic, nullable) UIFont *cbr_DocTypeScreenFooterTextFont;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_DocTypeScreenFooterTextColor;
/**
 * Matches to `colors.contentLink` by default
 */
@property (nonatomic, nullable) UIColor *cbr_DocTypeScreenFooterLinkColor;

/**
 * Matches to `fonts.headline2` by default
 */
@property (nonatomic, nullable) UIFont *cbr_DocTypeScreenSectionTitleFont;
/**
 * Matches to `colors.contentStrong` by default
 */
@property (nonatomic, nullable) UIColor *cbr_DocTypeScreenSectionTitleColor;

/**
 * Matches to `metrics.sectionHeaderAlignment` by default
 */
@property (nonatomic) NSTextAlignment cbr_DocTypeScreenSectionTitleAlignment;

/**
 * Matches to `fonts.headline2` by default
 */
@property (nonatomic, nullable) UIFont *cbr_DocTypeScreenSectionSubtitleFont;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_DocTypeScreenSectionSubtitleColor;

/**
 * Matches to `fonts.subtitle1` by default
 */
@property (nonatomic, nullable) UIFont *cbr_DocTypeScreenItemTextFont;
/**
 * Matches to `colors.backgroundNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_DocTypeScreenItemBackgroundColor;
/**
 * Matches to `colors.contentStrong` by default
 */
@property (nonatomic, nullable) UIColor *cbr_DocTypeScreenItemTextColor;
/**
 * Matches to `colors.fieldPlaceholder` by default
 */
@property (nonatomic, nullable) UIColor *cbr_DocTypeScreenItemPlaceholderColor;

/**
 * Matches to `images.iconDisclosure` by default
 */
@property (nonatomic, nullable) UIImage *cbr_DocTypeScreenItemDisclosureImage;

/**
 * The paddings applied to the item cells at the DocType Selector Screen
 *
 * Default are: 12pt vertically and 12pt horizontally
 */
@property (nonatomic) UIEdgeInsets cbr_DocTypeScreenItemPaddings;

/**
 * The mininum height of the item cells at the DocType Selector Screen
 *
 * Default is 0
 */
@property (nonatomic) CGFloat cbr_DocTypeScreenItemMinHeight;

/**
 * The horizontal spacing between icons and the texts at the DocType Selector Screen
 *
 * Default is 8pt
 */
@property (nonatomic) CGFloat cbr_DocTypeScreenItemIconSpacing;

/**
 * Use to force the vertically centering of the elements on the item cells at the DocType Selector Screen
 *
 * Default is false
 */
@property (nonatomic) BOOL cbr_DocTypeScreenItemVerticallyCentering;

/**
 * Matches to `metrics.cardCornerRadius`
 */
@property (nonatomic) CGFloat cbr_DocTypeScreenItemCornerRadius;

#pragma mark - Countries Screen

/**
 * Matches to `colors.backgroundCommon`
 */
@property (nonatomic, nullable) UIColor *cbr_CountriesScreenBackgroundColor CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `colors.listSeparator`
 */
@property (nonatomic, nullable) UIColor *cbr_CountriesScreenSeparatorColor CBR_THEME_DEPRECATED("Unused");

/**
 * Matches to `fonts.subtitle2`
 */
@property (nonatomic, nullable) UIFont *cbr_CountriesScreenItemTextFont CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `colors.contentNeutral`
 */
@property (nonatomic, nullable) UIColor *cbr_CountriesScreenItemTextColor CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `colors.listSelectedItemBackground`
 */
@property (nonatomic, nullable) UIColor *cbr_CountriesScreenSelectedItemBackgroundColor CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `colors.contentNeutral`
 */
@property (nonatomic, nullable) UIColor *cbr_CountriesScreenSelectedItemTextColor CBR_THEME_DEPRECATED("Unused");

/**
 * Matches to `fonts.subtitle2`
 */
@property (nonatomic, nullable) UIFont *cbr_CountriesScreenSearchFieldFont CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `colors.fieldContent`
 */
@property (nonatomic, nullable) UIColor *cbr_CountriesScreenSearchFieldTextColor CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `colors.fieldBackground`
 */
@property (nonatomic, nullable) UIColor *cbr_CountriesScreenSearchFieldBackgroundColor CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `colors.fieldBorder`
 */
@property (nonatomic, nullable) UIColor *cbr_CountriesScreenSearchFieldBorderColor CBR_THEME_DEPRECATED("Unused");

#pragma mark - Camera Screen

@property (nonatomic, nullable) UIColor *cbr_CameraScreenBackgroundColor CBR_THEME_DEPRECATED("Replaced with `colors.cameraBackground`");
/**
 * Matches to `colors.cameraContent` by default
 */
@property (nonatomic, nullable) UIColor *cbr_CameraScreenSpinnerColor;

/**
 * Matches to `colors.cameraContent` by default
 */
@property (nonatomic, nullable) UIColor *cbr_CameraScreenCloseButtonTintColor;
/**
 * Matches to `colors.cameraContent` by default
 */
@property (nonatomic, nullable) UIColor *cbr_CameraScreenTorchButtonTintColor;

/**
 * Default is #FFFFFF
 */
@property (nonatomic, nullable) UIColor *cbr_CameraScreenCaptureButtonColor;
/**
 * Default is #F4F4F4
 */
@property (nonatomic, nullable) UIColor *cbr_CameraScreenCaptureButtonHighlightedColor;

@property (nonatomic, nullable) UIFont *cbr_CameraScreenScanResultStatusTextFont CBR_THEME_DEPRECATED("Unused");
@property (nonatomic, nullable) UIColor *cbr_CameraScreenScanResultStatusTextColor CBR_THEME_DEPRECATED("Unused");
@property (nonatomic, nullable) UIColor *cbr_CameraScreenScanResultStatusBackgroundColor CBR_THEME_DEPRECATED("Unused");
@property (nonatomic, nullable) UIColor *cbr_CameraScreenScanActivityIndicatorColor CBR_THEME_DEPRECATED("Unused");

/**
 * Matches to `fonts.headline2` by default
 */
@property (nonatomic, nullable) UIFont *cbr_CameraScreenInfoTitleFont;
/**
 * Matches to `fonts.body` by default
 */
@property (nonatomic, nullable) UIFont *cbr_CameraScreenInfoTextFont;
/**
 * Matches to `colors.bottomSheetBackground` by default
 */
@property (nonatomic, nullable) UIColor *cbr_CameraScreenInfoBackgroundColor;
/**
 * Matches to `colors.contentStrong` by default
 */
@property (nonatomic, nullable) UIColor *cbr_CameraScreenInfoTitleColor;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_CameraScreenInfoTextColor;
/**
 * Matches to `colors.bottomSheetHandle` by default
 */
@property (nonatomic, nullable) UIColor *cbr_CameraScreenInfoHandlerOutsideColor;
/**
 * Matches to `colors.bottomSheetHandle` by default
 */
@property (nonatomic, nullable) UIColor *cbr_CameraScreenInfoHandlerInsideColor;

/**
 * Default is `.center`
 */
@property (nonatomic) NSTextAlignment cbr_CameraScreenInfoTitleAlignment;
/**
 * Default is `.center`
 */
@property (nonatomic) NSTextAlignment cbr_CameraScreenInfoBriefAlignment;
/**
 * Default is `.natural`
 */
@property (nonatomic) NSTextAlignment cbr_CameraScreenInfoDetailsAlignment;

@property (nonatomic, nullable) UIImage *cbr_CameraScreenTorchOnImage CBR_THEME_DEPRECATED("Use `images.iconTorchOn` instead.");
@property (nonatomic, nullable) UIImage *cbr_CameraScreenTorchOffImage CBR_THEME_DEPRECATED("Use `images.iconTorchOff` instead.");

@property (nonatomic, nullable) UIImage *cbr_CameraScreenGalleryImage CBR_THEME_DEPRECATED("Use `images.iconGallery` instead.");

#pragma mark - Video Screen

/**
 * Matches to `colors.backgroundCommon` by default
 */
@property (nonatomic, nullable) UIColor *cbr_VideoScreenBackgroundColor;
/**
 * Matches to `colors.backgroundCommon` by default
 */
@property (nonatomic, nullable) UIColor *cbr_VideoScreenDimColor;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_VideoScreenSpinnerColor;

/**
 * Matches to `fonts.headline1` by default
 */
@property (nonatomic, nullable) UIFont *cbr_VideoScreenCountDownFont;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_VideoScreenCountDownColor;

/**
 * Matches to `colors.navigationBarItem` by default
 */
@property (nonatomic, nullable) UIColor *cbr_VideoScreenCloseButtonTintColor;

/**
 * Matches to `colors.contentWeak` with alpha 40% by default
 */
@property (nonatomic, nullable) UIColor *cbr_VideoScreenRecordButtonBorderColor;
/**
 * Matches to `colors.contentCritical` by default
 */
@property (nonatomic, nullable) UIColor *cbr_VideoScreenRecordingColor;

/**
 * Matches to `colors.contentInfo` by default
 */
@property (nonatomic, nullable) UIColor *cbr_VideoScreenViewPortBorderColor;
/**
 * Matches to `colors.contentInfo` by default
 */
@property (nonatomic, nullable) UIColor *cbr_VideoScreenViewPortBorderActiveColor;
/**
 * Matches to `metrics.viewportBorderWidth` by default
 */
@property (nonatomic) CGFloat cbr_VideoScreenViewPortBorderWidth;

/**
 * Matches to `fonts.headline1` by default
 */
@property (nonatomic, nullable) UIFont *cbr_VideoScreenReadAloudTextFont;

/**
 * Foreground color of the Video Screen's panel the text to read is displayed at
 *
 * Default is #FFFFFF
 */
@property (nonatomic, nullable) UIColor *cbr_VideoScreenReadAloudTextColor;
/**
 * Background color of the Video Screen's panel the text to read is displayed at
 *
 * Default is #1E232E
 */
@property (nonatomic, nullable) UIColor *cbr_VideoScreenReadAloudBackgroundColor;

/**
 * Matches to `fonts.headline1` by default
 */
@property (nonatomic, nullable) UIFont *cbr_VideoScreenFooterHeaderFont;
/**
 * Matches to `fonts.subtitle1` by default
 */
@property (nonatomic, nullable) UIFont *cbr_VideoScreenFooterTextFont;
/**
 * Matches to `colors.contentStrong` by default
 */
@property (nonatomic, nullable) UIColor *cbr_VideoScreenFooterHeaderColor;
/**
 * Matches to `colors.contentStrong` by default
 */
@property (nonatomic, nullable) UIColor *cbr_VideoScreenFooterTextColor;

#pragma mark - FaceScan Screen

/**
 * Matches to `fonts.headline2` by default
 */
@property (nonatomic, nullable) UIFont *cbr_FaceScanScreenResultTitleFont;
/**
 * Matches to `fonts.subtitle2` by default
 */
@property (nonatomic, nullable) UIFont *cbr_FaceScanScreenResultTextFont;
/**
 * Matches to `fonts.headline2` by default
 */
@property (nonatomic, nullable) UIFont *cbr_FaceScanScreenHintFont;

/**
 * Matches to `colors.backgroundCommon` by default
 */
@property (nonatomic, nullable) UIColor *cbr_FaceScanScreenBackgroundColor;
/**
 * Matches to `colors.navigationBarItem` by default
 */
@property (nonatomic, nullable) UIColor *cbr_FaceScanScreenCloseButtonTintColor;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_FaceScanScreenSpinnerColor;

/**
 * Matches to `colors.contentStrong` by default
 */
@property (nonatomic, nullable) UIColor *cbr_FaceScanScreenResultTitleColor;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_FaceScanScreenResultTextColor;
/**
 * Matches to `colors.contentStrong` by default
 */
@property (nonatomic, nullable) UIColor *cbr_FaceScanScreenHintColor;
/**
 * Matches to `colors.contentSuccess` by default
 */
@property (nonatomic, nullable) UIColor *cbr_FaceScanScreenOvalColor;

/**
 * The color applied to the hint text at the FaceScan Screen when low light conditions are detected
 *
 * Default is #333333
 */
@property (nonatomic, nullable) UIColor *cbr_FaceScanScreenLowLightHintColor;
/**
 * The color applied to the close button at the FaceScan Screen when low light conditions are detected
 *
 * Default is #333333
 */
@property (nonatomic, nullable) UIColor *cbr_FaceScanScreenLowLightCloseButtonTintColor;

/**
 * Matches to `images.pictureSuccess` by default
 */
@property (nonatomic, nullable) UIImage *cbr_FaceScanScreenSuccessImage;
/**
 * Matches to `images.pictureFailure` by default
 */
@property (nonatomic, nullable) UIImage *cbr_FaceScanScreenFailedImage;
/**
 * Matches to `images.pictureSubmitted` by default
 */
@property (nonatomic, nullable) UIImage *cbr_FaceScanScreenSubmittedImage;

/**
 * Size of the image displayed at the FaceScan Screen when the processing is done
 *
 * Equals to `cbr_StatusHeaderImageSize` by default (112pt x 112pt)
 */
@property (nonatomic) CGSize cbr_FaceScanScreenResultImageSize;

#pragma mark - Preview Screen

/**
 * Matches to `fonts.headline2` by default
 */
@property (nonatomic, nullable) UIFont *cbr_PreviewScreenTitleFont;
/**
 * Matches to `fonts.subtitle2` by default
 */
@property (nonatomic, nullable) UIFont *cbr_PreviewScreenSubtitleFont;
/**
 * Matches to `colors.backgroundCommon` by default
 */
@property (nonatomic, nullable) UIColor *cbr_PreviewScreenBackgroundColor;
/**
 * Matches to `colors.contentStrong` by default
 */
@property (nonatomic, nullable) UIColor *cbr_PreviewScreenTitleColor;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_PreviewScreenSubtitleColor;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_PreviewScreenSpinnerColor;

@property (nonatomic, nullable) UIImage *cbr_PreviewScreenVideoPlayImage CBR_THEME_DEPRECATED("Use `images.iconPlay` instead.");

/**
 * Matches to `metrics.bottomSheetCornerRadius` by default
 */
@property (nonatomic) CGFloat cbr_PreviewScreenSliderCornerRadius;
/**
 * Specifies the shift of the warning icon displayed at the top right corner of the slider (only vertical shift is applied)
 *
 * Default vertical shift is 0pt
 */
@property (nonatomic) CGPoint cbr_PreviewScreenSliderIconPosition;

/**
 * Matches to `fonts.subtitle2` by default
 */
@property (nonatomic, nullable) UIFont *cbr_PreviewScreenSliderBriefFont;
/**
 * Matches to `fonts.subtitle2` by default
 */
@property (nonatomic, nullable) UIFont *cbr_PreviewScreenSliderDetailsFont;
/**
 * Matches to `colors.bottomSheetBackground` by default
 */
@property (nonatomic, nullable) UIColor *cbr_PreviewScreenSliderBackgroundColor;
/**
 * Matches to `colors.bottomSheetHandle` by default
 */
@property (nonatomic, nullable) UIColor *cbr_PreviewScreenSliderHandlerColor;
/**
 * Matches to `colors.contentStrong` by default
 */
@property (nonatomic, nullable) UIColor *cbr_PreviewScreenSliderBriefColor;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_PreviewScreenSliderDetailsColor;
/**
 * Matches to `images.iconWarning` by default
 */
@property (nonatomic, nullable) UIImage *cbr_PreviewScreenSliderIconImage;

#pragma mark - Support Screen

/**
 * Matches to `fonts.subtitle1`
 */
@property (nonatomic, nullable) UIFont *cbr_SupportScreenItemButtonFont CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `fonts.body`
 */
@property (nonatomic, nullable) UIFont *cbr_SupportScreenItemDescriptionFont CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `colors.backgroundCommon`
 */
@property (nonatomic, nullable) UIColor *cbr_SupportScreenBackgroundColor CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `colors.contentStrong`
 */
@property (nonatomic, nullable) UIColor *cbr_SupportScreenItemButtonColor CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `colors.contentNeutral`
 */
@property (nonatomic, nullable) UIColor *cbr_SupportScreenItemDescriptionColor CBR_THEME_DEPRECATED("Unused");

@property (nonatomic, nullable) UIColor *cbr_SupportScreenEmailImageTintColor CBR_THEME_DEPRECATED("Unused");
@property (nonatomic, nullable) UIImage *cbr_SupportScreenEmailImage CBR_THEME_DEPRECATED("Replaced with `images.iconMail`");

#pragma mark - ToS Screen

/**
 * Matches to `colors.backgroundCommon` by default
 */
@property (nonatomic, nullable) UIColor *cbr_TosScreenBackgroundColor;
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_TosScreenSpinnerColor;

#pragma mark - Applicant Data Screen

/**
 * Matches to `colors.backgroundCommon` by default
 */
@property (nonatomic, nullable) UIColor *cbr_DataScreenBackgroundColor CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `colors.contentNeutral` by default
 */
@property (nonatomic, nullable) UIColor *cbr_DataScreenSpinnerColor CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `colors.listSeparator` by default
 */
@property (nonatomic, nullable) UIColor *cbr_DataScreenSeparatorColor CBR_THEME_DEPRECATED("Unused");

/**
 * Matches to `fonts.subtitle2` by default
 */
@property (nonatomic, nullable) UIFont *cbr_DataScreenNameFont CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `fonts.subtitle2` by default
 */
@property (nonatomic, nullable) UIFont *cbr_DataScreenValueFont CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `colors.contentStrong` by default
 */
@property (nonatomic, nullable) UIColor *cbr_DataScreenNameColor CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `colors.fieldContent` by default
 */
@property (nonatomic, nullable) UIColor *cbr_DataScreenValueColor CBR_THEME_DEPRECATED("Unused");
/**
 * Matches to `colors.contentCritical` by default
 */
@property (nonatomic, nullable) UIColor *cbr_DataScreenErrorColor CBR_THEME_DEPRECATED("Unused");

@end
