//
//  CBREvent.h
//  CyberityMobileSDK
//

#import <Foundation/Foundation.h>

/**
 * Event type
 */
typedef NS_ENUM(NSInteger, CBREventType) {
    /**
     * Fired when the applicant is loaded
     *
     * @discussion Cast the event to `CBREventApplicantLoaded` in order to get the event parameters
     */
    CBREventType_ApplicantLoaded,

    /**
     * Fired when a verification step has been initiated
     *
     * @discussion Cast the event to `CBREventStepInitiated` in order to get the event parameters
     */
    CBREventType_StepInitiated,
    
    /**
     * Fired when a verification step has been completed
     *
     * @discussion Cast the event to `CBREventStepCompleted` in order to get the event parameters
     */
    CBREventType_StepCompleted,
    
    /**
     * Fired when an analytics event has occured
     *
     * @discussion Cast the event to `CBREventAnalytics` in order to get the event parameters
     */
    CBREventType_Analytics,
};

typedef NSString * _Nonnull CBREventKey NS_TYPED_ENUM;

extern CBREventKey const CBREventKey_applicantId NS_SWIFT_NAME(applicantId);
extern CBREventKey const CBREventKey_idDocSetType NS_SWIFT_NAME(idDocSetType);
extern CBREventKey const CBREventKey_isCancelled NS_SWIFT_NAME(isCancelled);
extern CBREventKey const CBREventKey_eventName NS_SWIFT_NAME(eventName);
extern CBREventKey const CBREventKey_eventPayload NS_SWIFT_NAME(eventPayload);

#pragma mark -

/**
 * Generic event
 *
 * @discussion
 *      All the events are passed into `sdk.onEvent` callback as instances of a concrete `CBREvent*` class
 *      inherited from the `CBREvent` base class that ensures that each event has its type - `eventType`
 *      and an optional set of parameters - `payload`.
 *
 *      Depending on your needs you can get event parameters either by examining the `payload`
 *      or by casting the given event instance to a specific `CBREvent*` class according to its type.
 */
@interface CBREvent : NSObject

/**
 * Event type
 */
@property (nonatomic, readonly) CBREventType eventType;

/**
 * Event payload
 *
 * @discussion The payload is represented by a raw dictionary. The concrete set of keys depends on the event type.
 */
@property (nonatomic, readonly, nonnull) NSDictionary <CBREventKey, id> *payload;

/**
 * Provides default description for the given event type
 */
- (nonnull NSString *)descriptionForEventType:(CBREventType)eventType;

@end


#pragma mark -

/**
 * The applicant has been loaded
 */
@interface CBREventApplicantLoaded : CBREvent

@property (nonatomic, readonly, nonnull) NSString *applicantId;

@end

#pragma mark -

/**
 * A verification step has been initiated
 */
@interface CBREventStepInitiated : CBREvent

@property (nonatomic, readonly, nonnull) NSString *idDocSetType;

@end

#pragma mark -

/**
 * A verification step has been fulfilled or cancelled
 */
@interface CBREventStepCompleted : CBREvent

@property (nonatomic, readonly, nonnull) NSString *idDocSetType;
@property (nonatomic, readonly) BOOL isCancelled;

@end

/**
 * Analytics event
 */
@interface CBREventAnalytics : CBREvent

@property (nonatomic, readonly, nonnull) NSString *eventName;
@property (nonatomic, readonly, nullable) NSDictionary<NSString *, id> *eventPayload;

@end
