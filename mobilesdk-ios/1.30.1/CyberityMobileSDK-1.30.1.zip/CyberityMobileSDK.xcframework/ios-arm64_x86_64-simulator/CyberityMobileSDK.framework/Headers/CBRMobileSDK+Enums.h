//
//  CBRMobileSDK+Enums.h
//  CyberityMobileSDK
//

#ifndef CBRMobileSDK_Enums_h
#define CBRMobileSDK_Enums_h

/**
 * Environment the SDK should operate on
 */
typedef NSString * CBREnvironment NS_TYPED_EXTENSIBLE_ENUM;
/// Production environment
extern CBREnvironment _Nonnull const CBREnvironmentProduction;

/**
 * SDK Status
 */
typedef NS_CLOSED_ENUM(NSInteger, CBRMobileSDKStatus) {
    
    /// SDK is initialized and ready to be presented
    CBRMobileSDKStatus_Ready,
    
    /// SDK fails for some reasons (see `failReason` and `verboseStatus` for details)
    CBRMobileSDKStatus_Failed,
    
    /// No verification steps are passed yet
    CBRMobileSDKStatus_Initial,
    
    /// Some but not all of the verification steps have been passed over
    CBRMobileSDKStatus_Incomplete,
    
    /// Verification is pending
    CBRMobileSDKStatus_Pending,
    
    /// Applicant has been declined temporarily
    CBRMobileSDKStatus_TemporarilyDeclined,
    
    /// Applicant has been finally rejected
    CBRMobileSDKStatus_FinallyRejected,
    
    /// Applicant has been approved
    CBRMobileSDKStatus_Approved,
    
    /// Applicant action has been completed (see `actionResult` for details)
    CBRMobileSDKStatus_ActionCompleted,
    
} NS_SWIFT_NAME(CBRMobileSDK.Status);


/**
 * Fail reasons (see `verboseStatus` for details of the fail)
 */
typedef NS_ENUM(NSInteger, CBRFailReason) {
    
    /// Unknown or no fail
    CBRFailReason_Unknown,
    
    /// An attempt to setup with invalid parameters
    CBRFailReason_InvalidParameters,
    
    /// Unauthorized access detected (most likely `accessToken` is invalid or expired and had failed to be refreshed)
    CBRFailReason_Unauthorized,
    
    /// Initial loading from backend is failed
    CBRFailReason_InitialLoadingFailed,
    
    /// No applicant is found for the given parameters
    CBRFailReason_ApplicantNotFound,
    
    /// Applicant is found, but is misconfigured (most likely lacks of idDocs)
    CBRFailReason_ApplicantMisconfigured,
    
    /// A network error occured (the user will be presented with Network Oops screen)
    CBRFailReason_NetworkError,
    
    /// Some unexpected error occured (the user will be presented with Fatal Oops screen)
    CBRFailReason_UnexpectedError,
    
    /// An initialization error occured
    CBRFailReason_InitializationError,
};

/**
 * Reactions of `actionResultHandler`
 */
typedef NS_ENUM(NSInteger, CBRActionResultHandlerReaction) {
    
    /// Allows further processing to be continued
    CBRActionResultHandlerReaction_Continue = 0,
    
    /// Cancels further processing
    CBRActionResultHandlerReaction_Cancel = 1,
    
};

/**
 * Log levels
 */
typedef NS_ENUM(NSInteger, CBRLogLevel) {
    
    /// Logs nothing
    CBRLogLevel_Off = 0,
    
    /// Logs errors (default)
    CBRLogLevel_Error = 1,
    
    /// Logs warnings
    CBRLogLevel_Warning = 2,
    
    /// Logs debug info
    CBRLogLevel_Info = 3,
    
    /// Logs even more debug info
    CBRLogLevel_Debug = 4,
    
    /// Logs as much as possible
    CBRLogLevel_Trace = 5
};

#pragma mark -

typedef NSString * CBRVerificationStepKey NS_TYPED_EXTENSIBLE_ENUM;
extern CBRVerificationStepKey _Nonnull const CBRVerificationStepKeyDefault;
extern CBRVerificationStepKey _Nonnull const CBRVerificationStepKeyIdentity;
extern CBRVerificationStepKey _Nonnull const CBRVerificationStepKeyIdentity2;
extern CBRVerificationStepKey _Nonnull const CBRVerificationStepKeyIdentity3;
extern CBRVerificationStepKey _Nonnull const CBRVerificationStepKeyIdentity4;
extern CBRVerificationStepKey _Nonnull const CBRVerificationStepKeySelfie;
extern CBRVerificationStepKey _Nonnull const CBRVerificationStepKeySelfie2;
extern CBRVerificationStepKey _Nonnull const CBRVerificationStepKeyProofOfResidence;
extern CBRVerificationStepKey _Nonnull const CBRVerificationStepKeyProofOfResidence2;
extern CBRVerificationStepKey _Nonnull const CBRVerificationStepKeyApplicantData;
extern CBRVerificationStepKey _Nonnull const CBRVerificationStepKeyEmailVerification;
extern CBRVerificationStepKey _Nonnull const CBRVerificationStepKeyPhoneVerification;
extern CBRVerificationStepKey _Nonnull const CBRVerificationStepKeyQuestionnaire;
extern CBRVerificationStepKey _Nonnull const CBRVerificationStepKeyVideoIdent;
extern CBRVerificationStepKey _Nonnull const CBRVerificationStepKeyEkyc;

typedef NSString * CBRVerificationStepState NS_TYPED_EXTENSIBLE_ENUM;
extern CBRVerificationStepState _Nonnull const CBRVerificationStepStateNotSubmitted;
extern CBRVerificationStepState _Nonnull const CBRVerificationStepStateSubmitted;
extern CBRVerificationStepState _Nonnull const CBRVerificationStepStateReviewing;
extern CBRVerificationStepState _Nonnull const CBRVerificationStepStateApproved;
extern CBRVerificationStepState _Nonnull const CBRVerificationStepStateDeclined;

typedef NSString * CBRDocumentTypeKey NS_TYPED_EXTENSIBLE_ENUM;
extern CBRDocumentTypeKey _Nonnull const CBRDocumentTypeKeyDefault;
extern CBRDocumentTypeKey _Nonnull const CBRDocumentTypeKeyIdCard;
extern CBRDocumentTypeKey _Nonnull const CBRDocumentTypeKeyPassport;
extern CBRDocumentTypeKey _Nonnull const CBRDocumentTypeKeyDrivers;
extern CBRDocumentTypeKey _Nonnull const CBRDocumentTypeKeyResidencePermit;

typedef NSString * CBRSceneType NS_TYPED_EXTENSIBLE_ENUM;
extern CBRSceneType _Nonnull const CBRSceneTypeFacescan;
extern CBRSceneType _Nonnull const CBRSceneTypeVideoSelfie;
extern CBRSceneType _Nonnull const CBRSceneTypePhotoSelfie;
extern CBRSceneType _Nonnull const CBRSceneTypePortraitSelfie;
extern CBRSceneType _Nonnull const CBRSceneTypeScanFrontSide;
extern CBRSceneType _Nonnull const CBRSceneTypeScanBackSide;
extern CBRSceneType _Nonnull const CBRSceneTypeData;
extern CBRSceneType _Nonnull const CBRSceneTypeConfirmation;
extern CBRSceneType _Nonnull const CBRSceneTypeQuestionnaire;
extern CBRSceneType _Nonnull const CBRSceneTypeVideoIdent;
extern CBRSceneType _Nonnull const CBRSceneTypeGeolocation;
extern CBRSceneType _Nonnull const CBRSceneTypeEkyc;

typedef NSString * CBRInstructionsBlockType NS_TYPED_EXTENSIBLE_ENUM;
extern CBRInstructionsBlockType _Nonnull const CBRInstructionsBlockTypeSingle;
extern CBRInstructionsBlockType _Nonnull const CBRInstructionsBlockTypeDo;
extern CBRInstructionsBlockType _Nonnull const CBRInstructionsBlockTypeDont;

typedef NS_ENUM(NSInteger, CBRInstructionsPlacement) {
    CBRInstructionsPlacement_InstructionsScreen,
    CBRInstructionsPlacement_BottomSheet,
};

#endif /* CBRMobileSDK_Enums_h */
